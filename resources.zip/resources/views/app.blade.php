<!DOCTYPE html>
<html lang="en">
  @include('layouts.includes.head');
  <body>
	  @include('layouts.includes.nav');
    
    <div class="hero-wrap" style="background-image: url('user/images/1.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-end" data-scrollax-parent="true">
          <div class="col-md-6 order-md-last ftco-animate mt-5" data-scrollax=" properties: { translateY: '70%' }">
            <h1 class="mb-4" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">Les't Learn Code To Make More Exploitation</h1>
            <p><a href="#" class="btn btn-black py-3 px-4">Join US!!!</a></p>
          </div>
        </div>
      </div>
    </div>

    <section class="services-section py-5 py-md-0 bg-light">
      <div class="container">
        <div class="row no-gutters d-flex">
          <div class="col-md-6 col-lg-3 d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services d-block">
              <div class="icon"><span class="flaticon-charity"></span></div>
              <div class="media-body">
                <h3 class="heading mb-3">Help</h3>
                <p>	203 Fake St. Mountain View, San Francisco, California, USA</p>
              </div>
            </div>      
          </div>
          <div class="col-md-6 col-lg-3 d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services d-block">
              <div class="icon"><span class="flaticon-adoption"></span></div>
              <div class="media-body">
                <h3 class="heading mb-3">Support</h3>
                <p>A small river named Duden flows by their place and supplies.</p>
              </div>
            </div>    
          </div>
          <div class="col-md-6 col-lg-3 d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services active d-block">
              <div class="icon"><span class="flaticon-volunteer"></span></div>
              <div class="media-body">
                <h3 class="heading mb-3">Communication</h3>
                <p>A small river named Duden flows by their place and supplies.</p>
              </div>
            </div>      
          </div>
          <div class="col-md-6 col-lg-3 d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services d-block">
              <div class="icon"><span class="flaticon-open-book"></span></div>
              <div class="media-body">
                <h3 class="heading mb-3">Learning</h3>
                <p>A small river named Duden flows by their place and supplies.</p>
              </div>
            </div>      
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section ftco-causes">
    	<div class="container">
    		<div class="row justify-content-center pb-3">
          <div class="col-md-10 heading-section text-center ftco-animate">
            <h2 class="mb-4">let's the world learn with us</h2>
            <p>About Us</p>
          </div>
        </div>
    	</div>
    	<div class="container">
        <div class="row">
        	<div class="col-md-12">
        		<div class="carousel-causes owl-carousel">
        			<div class="item">
		        		<a href="causes.html" class="causes text-center">
		        			<div class="img" style="background-image: url(user/images/bug.png);"></div>
		        			<h2>BUG HUNTER</h2>
		        		</a>
        			</div>
        			<div class="item">
	        			<a href="causes.html" class="causes text-center">
		        			<div class="img" style="background-image: url(user/images/dev.png);"></div>
		        			<h2>WebDev</h2>
		        		</a>
	        		</div>
	        		<div class="item">
	        			<a href="causes.html" class="causes text-center">
		        			<div class="img" style="background-image: url(user/images/andro.png);"></div>
		        			<h2>Mobile App Dev</h2>
		        		</a>
	        		</div>
	        		<div class="item">
	        			<a href="causes.html" class="causes text-center">
		        			<div class="img" style="background-image: url(user/images/linux.png);"></div>
		        			<h2>Linux</h2>
		        		</a>
	        		</div>
        		</div>
        	</div>
        </div>
    	</div>
    </section>
   	
   	<section class="testimony-section">
      <div class="container">
        <div class="row ftco-animate justify-content-center">
        	<div class="col-md-6 d-flex">
        		<div class="testimony-img" style="background-image: url(user/images/team.png);"></div>
        	</div>
          <div class="col-md-6 py-5">
          	<div class="heading-section heading-section-white pt-4 ftco-animate">
		          <h2 class="mb-0">Official Member</h2>
		        </div>
            <div class="carousel-testimony owl-carousel ftco-owl">
              <div class="item">
                <div class="testimony-wrap pb-4">
                  <div class="text">
                    <p class="mb-4">Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
                  </div>
                  <div class="d-flex">
	                  <div class="user-img" style="background-image: url(user/images/person_1.jpg)">
	                  </div>
	                  <div class="pos ml-3">
	                  	<p class="name">GeNeRaL</p>
	                    <span class="position">Fouder</span>
	                  </div>
	                </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap pb-4">
                  <div class="text">
                    <p class="mb-4">UP YOUR SKILL AND UP YOUR BRAIN!!!</p>
                  </div>
                  <div class="d-flex">
	                  <div class="user-img" style="background-image: url(user/images/maul.jpg)">
	                  </div>
	                  <div class="pos ml-3">
	                  	<p class="name">root@M3e.X~#</p>
	                    <span class="position">CO-FOUDER</span>
	                  </div>
	                </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap pb-4">
                  <div class="text">
                    <p class="mb-4">Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
                  </div>
                  <div class="d-flex">
	                  <div class="user-img" style="background-image: url(user/images/person_1.jpg)">
	                  </div>
	                  <div class="pos ml-3">
	                  	<p class="name">ZX7</p>
	                    <span class="position">CEO</span>
	                  </div>
	                </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap pb-4">
                  <div class="text">
                    <p class="mb-4">Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
                  </div>
                  <div class="d-flex">
	                  <div class="user-img" style="background-image: url(user/images/person_1.jpg)">
	                  </div>
	                  <div class="pos ml-3">
	                  	<p class="name">BABA YAGA</p>
	                    <span class="position">CEO</span>
	                  </div>
	                </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap pb-4">
                  <div class="text">
                    <p class="mb-4">Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
                  </div>
                  <div class="d-flex">
	                  <div class="user-img" style="background-image: url(user/images/person_1.jpg)">
	                  </div>
	                  <div class="pos ml-3">
	                  	<p class="name">VINCE</p>
	                    <span class="position">CEO</span>
	                  </div>
	                </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
   

    @include('layouts.includes.footer');
  </body>
</html>