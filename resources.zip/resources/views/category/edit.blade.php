@extends('home')
@section('content')
    <h1> Create Category</h1>
    <hr>
    <button class="btn btn-default"><a href="category/show">View all Categories</a></button>
    <button class="btn btn-default"><a href="category/create">Create new Categories</a></button>
    <hr>
    @if( Session::has('coc') )
    <div class="alert alert-success">
    <button class="close" data-dismiss="alert"></button>
    <strong>{{ session('cc') }}</strong>
    </div>
    @endif
    <hr>
    @if( Session::has('coc'))
    <div class="alert alert-danger">
    <button class="close" data-dismiss="alert"></button>
    <strong>{{ session('coc')}}</strong>
    <ul>
        @foreach ($errors->all() as $error)
            <li>
                {{$error}}
            </li>
            @endforeach
    </ul>
    </div>
    <hr>
    @endif
    <form method="post" action="{{ route('category.update',
     $category->id ) }}">
     {!! method_field('patch') !!}
    {{ csrf_field() }}
        <label>Enter new Category</label>
        <input type="text" name="name" value="{{ $category->name }}">
        <input type="submit" name="" value="Update">
    </form>
@endsection