<?php $__env->startSection('content'); ?>
    <h1>Category</h1>
    <hr>
    <button class="btn btn-default"><a href="category/show">View all Categories</a></button>
    <button class="btn btn-default"><a href="category/create">Create new Categories</a></button>
    <hr>
    <?php if( Session::has('coc') ): ?>
    <div class="alert alert-success">
    <button class="close" data-dismiss="alert"></button>
    <strong><?php echo e(session('cc')); ?></strong>
    </div>
    <?php endif; ?>
    <hr>
    <?php if( Session::has('coc')): ?>
    <div class="alert alert-danger">
    <button class="close" data-dismiss="alert"></button>
    <strong><?php echo e(session('coc')); ?></strong>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <?php echo e($error); ?>

            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    </div>
    <hr>
    <?php endif; ?>
    <table id="dtBasicExample" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
  <thead>
    <tr>
      <th class="th-sm">Name

      </th>
      <th class="th-sm">Id

      </th>
      <th class="th-sm">Create Time

      </th>
      <th class="th-sm">Update Time

      </th>
      <th class="th-sm">Edit

      </th>
      <th class="th-sm">Delete

      </th>
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $categories->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($category->name); ?></td>
      <td><?php echo e($category->id); ?></td>
      <td><?php echo e($category->created_at); ?></td>
      <td><?php echo e($category->updated_at); ?></td>
      <td><a href="<?php echo e(route('category.edit', $category->id )); ?>">Edit</a></td>
      <form action="<?php echo e(route('category.destroy',
      $category->id)); ?>" method="post">
      <?php echo e(method_field('delete')); ?>

    <?php echo e(csrf_field()); ?>

      <td><input type="submit" name="" value="Delete"></td></form>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
  <tfoot>
    <tr>
      <th>Name
      </th>
      <th>Id
      </th>
      <th>Create Time
      </th>
      <th>Update Time
      </th>
      <th>Edit
      </th>
      <th>Delete
      </th>
    </tr>
  </tfoot>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>