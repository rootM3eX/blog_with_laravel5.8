<?php $__env->startSection('content'); ?>
    <h1>Create Posts</h1>
    <hr>
    <button class="btn btn-default"><a href="post/show">View all Post</a></button>
    <button class="btn btn-default"><a href="post/create">Create new Post</a></button>
    <hr>
    <div class="container">
    <form action="<?php echo e(route('post.store')); ?>" method="post">
    <?php echo e(csrf_field()); ?>

  <fieldset>
    <legend>Create Post</legend>
    <div class="form-group">
      <label for="exampleInputEmail1">Enter Title</label>
      <input type="text" class="form-control" name="title" placeholder="Enter Title">
      </div>
    <div class="form-group">
      <label for="exampleInputPassword1">Author</label>
      <input type="text" class="form-control" name="author" placeholder="Author">
    </div>
    <div class="form-group">
      <label for="exampleSelect1">select</label>
      <select class="form-control" id="exampleSelect1" name="category_id">
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
    <div class="form-group">
      <label for="exampleTextarea">Enter Description</label>
      <textarea class="form-control" name="description" rows="3"></textarea>
    </div>
    <div class="form-group">
      <label for="exampleInputFile">File input</label>
      <input type="file" name="image" class="form-control-file" aria-describedby="fileHelp">
      <small id="fileHelp" class="form-text text-muted">Enter image</small>
    </div>
    <button type="submit" class="btn btn-primary"> Submit</button>
  </fieldset>
</form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>