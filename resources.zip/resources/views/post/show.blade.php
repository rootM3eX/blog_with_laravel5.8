@extends('home')
@section('content')
    <h1>View All Posts</h1>
    <hr>
    <button class="btn btn-default"><a href="post/show">View all posts</a></button>
    <button class="btn btn-default"><a href="post/create">Create new posts</a></button>
    <hr>
    @if( Session::has('coc') )
    <div class="alert alert-success">
    <button class="close" data-dismiss="alert"></button>
    <strong>{{ session('cc') }}</strong>
    </div>
    @endif
    <hr>
    @if( Session::has('coc'))
    <div class="alert alert-danger">
    <button class="close" data-dismiss="alert"></button>
    <strong>{{ session('coc')}}</strong>
    <ul>
        @foreach ($errors->all() as $error)
            <li>
                {{$error}}
            </li>
            @endforeach
    </ul>
    </div>
    <hr>
    @endif
    <table id="dtBasicExample" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
  <thead>
    <tr>
      <th class="th-sm">Title

      </th>
      <th class="th-sm">Author

      </th>
      <th class="th-sm">category

      </th>
      <th class="th-sm">Description

      </th>
      <th class="th-sm">Image

      </th>
      <th class="th-sm">Edit

      </th>
      <th class="th-sm">Delete

      </th>
    </tr>
  </thead>
  <tbody>
  @foreach($posts->all() as $post)
    <tr>
      <td>{{ $post->title }}</td>
      <td>{{ $post->author }}</td>
      <td>{{ $post->category_id }}</td>
      <td>{{ $post->description }}</td>
      <td><img src="{{ asset('img/$post->image')}}" width="40"></td>
      <td><a href="{{ route('post.edit', $post->id ) }}">Edit</a></td>
      <form action="{{ route('post.destroy',
      $post->id) }}" method="post">
      {{ method_field('delete') }}
    {{ csrf_field() }}
      <td><input type="submit" name="" value="Delete"></td></form>
    </tr>
    @endforeach
  </tbody>
  <tfoot>
    <tr>
      <th>Title
      </th>
      <th>Author
      </th>
      <th>category
      </th>
      <th>Description
      </th>
      <th>Image
      </th>
      <th>Edit
      </th>
      <th>Delete
      </th>
    </tr>
  </tfoot>
</table>
@endsection