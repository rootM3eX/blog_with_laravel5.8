<head>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.3.0/Chart.bundle.js"></script>
    <script type="text/javascript" src="chartjs/Chart.bundle.js"></script>
</head>
<body>
    <style type="text/css">body {font-family:roboto;}</style>
    <div style="width:500px; height:500px;">
    <canvas id="speedChart" width="600" height="400"></canvas>
    </div>

    <script>
        var speedCanvas = document.getElementById("speedChart");

Chart.defaults.global.defaultFontFamily = "Lato";
Chart.defaults.global.defaultFontSize = 18;

var speedData = {
  labels: ["0s", "10", "20", "30", "40", "50", "60"],
  datasets: [{
    label: "Car Speed (mph)",
    data: [0, 59, 75, 20, 20, 55, 40],
  }]
};

var chartOptions = {
  legend: {
    display: true,
    position: 'top',
    labels: {
      boxWidth: 80,
      fontColor: 'black'
    }
  }
};

var lineChart = new Chart(speedCanvas, {
  type: 'line',
  data: speedData,
  options: chartOptions
});
    </script>
</body>
</html>