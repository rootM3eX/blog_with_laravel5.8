<!DOCTYPE html>
<html lang="en"><head>
    <title>Contact Zone-Xploiter</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="<?php echo e(asset('https://fonts.googleapis.com/css?family=Nunito+Sans:200,300,400,600,700,800,900')); ?>" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset('user/css/open-iconic-bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user/css/animate.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('user/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user/css/owl.theme.default.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user/css/magnific-popup.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('user/css/aos.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('user/css/ionicons.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('user/css/bootstrap-datepicker.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user/css/jquery.timepicker.css')); ?>">

    
    <link rel="stylesheet" href="<?php echo e(asset('user/css/flaticon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user/css/icomoon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user/css/style.css')); ?>">
  </head>
  <body>
  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="index.html">Zone-Xploiter<span>.</span></a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	        	<li class="nav-item active"><a href="#" class="nav-link">Home</a></li>
	        	<li class="nav-item"><a href="about/index" class="nav-link">About</a></li>
	          <li class="nav-item"><a href="contact/" class="nav-link">Contact</a></li>
              <li class="nav-item"><a href="postview/" class="nav-link">Blog</a></li>
	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->
    <div class="hero-wrap" style="background-image: url('<?php echo e(asset('user/images/bg2.jpg')); ?>');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-end" data-scrollax-parent="true">
          <div class="col-md-6 order-md-last ftco-animate mt-5" data-scrollax=" properties: { translateY: '70%' }">
            <h1 class="mb-4" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">Les't Learn Code To Make More Exploitation</h1>
            <p><a href="#" class="btn btn-black py-3 px-4">Join US!!!</a></p>
          </div>
        </div>
      </div>
    </div>

    <section class="services-section py-5 py-md-0 bg-light">
      <div class="container">
        <div class="row no-gutters d-flex">
          <div class="col-md-6 col-lg-3 d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services d-block">
              <div class="icon"><span class="flaticon-charity"></span></div>
              <div class="media-body">
                <h3 class="heading mb-3">Help</h3>
                <p>	as a consultant about programming, bug hunter, linux, etc.</p>
              </div>
            </div>      
          </div>
          <div class="col-md-6 col-lg-3 d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services d-block">
              <div class="icon"><span class="flaticon-adoption"></span></div>
              <div class="media-body">
                <h3 class="heading mb-3">Support</h3>
                <p>The joined support Zone-Xploiter contact admin this website. </p>
              </div>
            </div>    
          </div>
          <div class="col-md-6 col-lg-3 d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services active d-block">
              <div class="icon"><span class="flaticon-volunteer"></span></div>
              <div class="media-body">
                <h3 class="heading mb-3">community</h3>
                <p>is one of the communities that are in Indonesia and formed in 22/02/2018.</p>
              </div>
            </div>      
          </div>
          <div class="col-md-6 col-lg-3 d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services d-block">
              <div class="icon"><span class="flaticon-open-book"></span></div>
              <div class="media-body">
                <h3 class="heading mb-3">Learning</h3>
                <p>Let's improve the quality of your skill and develop it.</p>
              </div>
            </div>      
          </div>
        </div>
      </div>
    </section>
    <br><br>
<!-- CONTACT-->
<link rel="stylesheet" href="<?php echo e(asset('user/css/contact.css')); ?>">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

  <!-- Contact Us Section -->
    <section class="Material-contact-section section-padding section-dark">
      <div class="container">
          <div class="row">
              <!-- Section Titile -->
              <div class="col-md-12 wow animated fadeInLeft" data-wow-delay=".2s">
                  <h3 class="section-title">Hallo, Tulis saran dan kritik di bawah ini</h3>
              </div>
          </div>
          <div class="row">
              <!-- Section Titile -->
              <div class="col-md-6 mt-3 contact-widget-section2 wow animated fadeInLeft" data-wow-delay=".2s">
                <p>Zone-Xploiter membuka saran dan kritikan dari kalian guys, jika ada dari kalian keluh kesan dan sran mohon isi sesuai data di bawah ini, admin akan merepon dengan cepat selama 24jam.</p>

                <div class="find-widget">
                 Address: <a href="#">Jakarta, Indonesia</a>
                </div>
                <div class="find-widget">
                  Phone:  <a href="#">+6289688125293</a>
                </div>
                
                <div class="find-widget">
                  Website:  <a href="#">www.zonexploiter.com</a>
                </div>
                <div class="find-widget">
                   Program: <a href="#">Open setiap hari pada: 09:30 AM - 00.00 PM</a>
                </div>
              </div>
              <!-- contact form -->
              <div class="col-md-6 wow animated fadeInRight" data-wow-delay=".2s">
                  <form class="shake" role="form" method="post" id="contactForm" name="contact-form" data-toggle="validator">
                      <!-- Name -->
                      <div class="form-group label-floating">
                        <label class="control-label" for="name">Name</label>
                        <input class="form-control" id="name" type="text" name="name" required data-error="Please enter your name">
                        <div class="help-block with-errors"></div>
                      </div>
                      <!-- email -->
                      <div class="form-group label-floating">
                        <label class="control-label" for="email">Email</label>
                        <input class="form-control" id="email" type="email" name="email" required data-error="Please enter your Email">
                        <div class="help-block with-errors"></div>
                      </div>
                      <!-- Subject -->
                      <div class="form-group label-floating">
                        <label class="control-label">Subject</label>
                        <input class="form-control" id="msg_subject" type="text" name="subject" required data-error="Please enter your message subject">
                        <div class="help-block with-errors"></div>
                      </div>
                      <!-- Message -->
                      <div class="form-group label-floating">
                          <label for="message" class="control-label">Message</label>
                          <textarea class="form-control" rows="3" id="message" name="message" required data-error="Write your message"></textarea>
                          <div class="help-block with-errors"></div>
                      </div>
                      <!-- Form Submit -->
                      <div class="form-submit mt-5">
                          <button class="btn btn-common" type="submit" id="form-submit"><i class="material-icons mdi mdi-message-outline"></i> Send Message</button>
                          <div id="msgSubmit" class="h3 text-center hidden"></div>
                          <div class="clearfix"></div>
                      </div>
                  </form>
              </div>
          </div>
      </div>
    </section>
    <br><br>
    <?php echo $__env->make('layouts.includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </body>
</html>