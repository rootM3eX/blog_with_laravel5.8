<?php $__env->startSection('content'); ?>
    <h1> Edit post</h1>
    <hr>
    <button class="btn btn-default"><a href="post/show">View all Posts</a></button>
    <button class="btn btn-default"><a href="post/create">Create new Posts</a></button>
    <hr>
    <?php if( Session::has('coc') ): ?>
    <div class="alert alert-success">
    <button class="close" data-dismiss="alert"></button>
    <strong><?php echo e(session('cc')); ?></strong>
    </div>
    <?php endif; ?>
    <hr>
    <?php if( Session::has('coc')): ?>
    <div class="alert alert-danger">
    <button class="close" data-dismiss="alert"></button>
    <strong><?php echo e(session('coc')); ?></strong>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <?php echo e($error); ?>

            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    </div>
    <hr>
    <?php endif; ?>
    
    <form method="post" action="<?php echo e(route('post.update',
     $post->id )); ?>">
     <?php echo method_field('patch'); ?>

    <?php echo e(csrf_field()); ?>

    <fieldset>
    <legend>Create Post</legend>
    <div class="form-group">
      <label for="exampleInputEmail1">Enter Title</label>
      <input type="text" class="form-control" name="title" placeholder="Enter Title" value="<?php echo e($post->title); ?>">
      </div>
    <div class="form-group">
      <label for="exampleInputPassword1">Author</label>
      <input type="text" class="form-control" name="author" placeholder="Author" value="<?php echo e($post->author); ?>">
    </div>
    <div class="form-group">
      <label for="exampleSelect1">select</label>
      <select class="form-control" id="exampleSelect1" name="category_id">
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($post->category_id); ?>"><?php echo e($category->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
    <div class="form-group">
      <label for="exampleTextarea">Enter Description</label>
      <textarea class="form-control" name="description" rows="3" placeholder="<?php echo e($post->description); ?>"></textarea>
    </div>
    <div class="form-group">
      <label for="exampleInputFile">File input</label>
      <input type="file" name="image" class="form-control-file" aria-describedby="fileHelp">
      <small id="fileHelp" class="form-text text-muted">Enter image</small>
    </div>
    <button type="submit" class="btn btn-primary"> Update</button>
  </fieldset>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>