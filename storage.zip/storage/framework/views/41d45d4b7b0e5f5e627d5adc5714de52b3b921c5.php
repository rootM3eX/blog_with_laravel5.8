<!DOCTYPE html>
<html lang="en"><head>
    <title>About Zone-Xploiter</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="<?php echo e(asset('https://fonts.googleapis.com/css?family=Nunito+Sans:200,300,400,600,700,800,900')); ?>" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset('user/css/open-iconic-bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user/css/animate.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('user/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user/css/owl.theme.default.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user/css/magnific-popup.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('user/css/aos.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('user/css/ionicons.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('user/css/bootstrap-datepicker.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user/css/jquery.timepicker.css')); ?>">

    
    <link rel="stylesheet" href="<?php echo e(asset('user/css/flaticon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user/css/icomoon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user/css/style.css')); ?>">
  </head>
  <body>
  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="index.html">Zone-Xploiter<span>.</span></a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	        	<li class="nav-item active"><a href="index.html" class="nav-link">Home</a></li>
	        	<li class="nav-item"><a href="about/index" class="nav-link">About</a></li>
	          <li class="nav-item"><a href="contact/" class="nav-link">Contact</a></li>
            <li class="nav-item"><a href="postview/" class="nav-link">Blog</a></li>
	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->
    <div class="hero-wrap" style="background-image: url('<?php echo e(asset('user/images/bg2.jpg')); ?>');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-end" data-scrollax-parent="true">
          <div class="col-md-6 order-md-last ftco-animate mt-5" data-scrollax=" properties: { translateY: '70%' }">
            <h1 class="mb-4" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">Les't Learn Code To Make More Exploitation</h1>
            <p><a href="#" class="btn btn-black py-3 px-4">Join US!!!</a></p>
          </div>
        </div>
      </div>
    </div>

    <section class="services-section py-5 py-md-0 bg-light">
      <div class="container">
        <div class="row no-gutters d-flex">
          <div class="col-md-6 col-lg-3 d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services d-block">
              <div class="icon"><span class="flaticon-charity"></span></div>
              <div class="media-body">
                <h3 class="heading mb-3">Help</h3>
                <p>	as a consultant about programming, bug hunter, linux, etc.</p>
              </div>
            </div>      
          </div>
          <div class="col-md-6 col-lg-3 d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services d-block">
              <div class="icon"><span class="flaticon-adoption"></span></div>
              <div class="media-body">
                <h3 class="heading mb-3">Support</h3>
                <p>The joined support Zone-Xploiter contact admin this website. </p>
              </div>
            </div>    
          </div>
          <div class="col-md-6 col-lg-3 d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services active d-block">
              <div class="icon"><span class="flaticon-volunteer"></span></div>
              <div class="media-body">
                <h3 class="heading mb-3">community</h3>
                <p>is one of the communities that are in Indonesia and formed in 22/02/2018.</p>
              </div>
            </div>      
          </div>
          <div class="col-md-6 col-lg-3 d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services d-block">
              <div class="icon"><span class="flaticon-open-book"></span></div>
              <div class="media-body">
                <h3 class="heading mb-3">Learning</h3>
                <p>Let's improve the quality of your skill and develop it.</p>
              </div>
            </div>      
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section ftco-causes">
      <div class="container">
        <div class="row justify-content-left pb-3">
          <div class="col-md-6 d-flex">
            <div class="col-md-10 heading-section text-center ftco-animate">
            <div class="causes text-left">
              <h3 class="mb-4">
               ABOUT US
              </h2>
              <hr color="blue">
                <h5>Zone-Xploiter di bangun pada 22-febuari-2018 yang berkonsep kekeluarga. dengan tujuan agar bermanfaat 
                kepada masyarakat, salah satunya yaitu memberikan pembelajaran edukasi ke pada masyarakat.</h5>
            </div>
          </div>
        </div>
      </div>
    </div>
    </section>

    
    <section class="ftco-section ftco-causes">
      <div class="container">
        <div class="row justify-content-left pb-3">
          <div class="col-md-6 d-flex">
            <div class="col-md-10 heading-section text-center ftco-animate">
              <div class="causes text-left">
              <h3 class="mb-4">
               Sponsor
              </h3>
              <hr color="blue">
              	<table>
                  <tr>
                    <td><img src="<?php echo e(asset('user/images/sosro.png')); ?>" title="sosro" width="100" height="100"> &nbsp; &nbsp; &nbsp; <img src="<?php echo e(asset('user/images/uda.png')); ?>" title="Udacoding"></td>
                  </tr>
                </table>
            </div>
          </div>
        </div>
      </div>
    </div>
    </section>

    <?php echo $__env->make('layouts.includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </body>
</html>