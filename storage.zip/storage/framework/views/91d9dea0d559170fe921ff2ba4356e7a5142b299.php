<?php $__env->startSection('content'); ?>
    <h1>View All Posts</h1>
    <hr>
    <button class="btn btn-default"><a href="post/show">View all posts</a></button>
    <button class="btn btn-default"><a href="post/create">Create new posts</a></button>
    <hr>
    <?php if( Session::has('coc') ): ?>
    <div class="alert alert-success">
    <button class="close" data-dismiss="alert"></button>
    <strong><?php echo e(session('cc')); ?></strong>
    </div>
    <?php endif; ?>
    <hr>
    <?php if( Session::has('coc')): ?>
    <div class="alert alert-danger">
    <button class="close" data-dismiss="alert"></button>
    <strong><?php echo e(session('coc')); ?></strong>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <?php echo e($error); ?>

            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    </div>
    <hr>
    <?php endif; ?>
    <table id="dtBasicExample" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
  <thead>
    <tr>
      <th class="th-sm">Title

      </th>
      <th class="th-sm">Author

      </th>
      <th class="th-sm">category

      </th>
      <th class="th-sm">Description

      </th>
      <th class="th-sm">Image

      </th>
      <th class="th-sm">Edit

      </th>
      <th class="th-sm">Delete

      </th>
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $posts->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($post->title); ?></td>
      <td><?php echo e($post->author); ?></td>
      <td><?php echo e($post->category_id); ?></td>
      <td><?php echo e($post->description); ?></td>
      <td><img src="<?php echo e(asset('img/$post->image')); ?>" width="40"></td>
      <td><a href="<?php echo e(route('post.edit', $post->id )); ?>">Edit</a></td>
      <form action="<?php echo e(route('post.destroy',
      $post->id)); ?>" method="post">
      <?php echo e(method_field('delete')); ?>

    <?php echo e(csrf_field()); ?>

      <td><input type="submit" name="" value="Delete"></td></form>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
  <tfoot>
    <tr>
      <th>Title
      </th>
      <th>Author
      </th>
      <th>category
      </th>
      <th>Description
      </th>
      <th>Image
      </th>
      <th>Edit
      </th>
      <th>Delete
      </th>
    </tr>
  </tfoot>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>