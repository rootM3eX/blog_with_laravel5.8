<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $posts->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="post-preview">
          <a href="<?php echo e(route('fullpost', [$post->id, str_slug('$post->title', '-') ])); ?>">
            <h2 class="post-title">
              <?php echo e($post->title); ?>

            </h2>
            <h3 class="post-subtitle">
              <?php echo e(substr("$post->description", 0,60)); ?>

            </h3>
          </a>
          <p class="post-meta">Post creation time 
            <a href="#"><?php echo e($post->created_at); ?></p>
        </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('postview.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>