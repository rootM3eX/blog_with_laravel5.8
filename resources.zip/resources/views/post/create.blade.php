@extends('home')
@section('content')
    <h1>Create Posts</h1>
    <hr>
    <button class="btn btn-default"><a href="post/show">View all Post</a></button>
    <button class="btn btn-default"><a href="post/create">Create new Post</a></button>
    <hr>
    <div class="container">
    <form action="{{ route('post.store')}}" method="post">
    {{ csrf_field() }}
  <fieldset>
    <legend>Create Post</legend>
    <div class="form-group">
      <label for="exampleInputEmail1">Enter Title</label>
      <input type="text" class="form-control" name="title" placeholder="Enter Title">
      </div>
    <div class="form-group">
      <label for="exampleInputPassword1">Author</label>
      <input type="text" class="form-control" name="author" placeholder="Author">
    </div>
    <div class="form-group">
      <label for="exampleSelect1">select</label>
      <select class="form-control" id="exampleSelect1" name="category_id">
      @foreach($categories as $category)
        <option value="{{ $category->id }}">{{ $category->name }}</option>
        @endforeach
      </select>
    </div>
    <div class="form-group">
      <label for="exampleTextarea">Enter Description</label>
      <textarea class="form-control" name="description" rows="3"></textarea>
    </div>
    <div class="form-group">
      <label for="exampleInputFile">File input</label>
      <input type="file" name="image" class="form-control-file" aria-describedby="fileHelp">
      <small id="fileHelp" class="form-text text-muted">Enter image</small>
    </div>
    <button type="submit" class="btn btn-primary"> Submit</button>
  </fieldset>
</form>
    </div>
@endsection