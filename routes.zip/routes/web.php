<?php

Route::get('/', function () {
    return view('app');
});

Route::get('fullpost/{id}/{title}', 'PostViewController@fullpost')->name('fullpost');
Route::get('postview', 'PostViewController@index');
Route::get('/uploadfile', 'UploadfileController@index');
Route::post('/uploadfile', 'UploadfileController@upload');
Route::get('/main', 'MainController@index');
Route::post('/main/checklogin', 'MainController@checklogin');
Route::get('/main/successlogin', 'MainController@successlogin');
Route::get('/main/logout', 'MainController@logout');
Auth::routes();
Route::get('/home', 'HomeController@index')->name('home');
Auth::routes();
Route::get('/home', 'HomeController@index')->name('home');
Route::get('/logout', '\App\Http\Controllers\Auth\LoginController@logout');
Route::resource('category', 'categoryController');
Route::resource('post', 'PostController');