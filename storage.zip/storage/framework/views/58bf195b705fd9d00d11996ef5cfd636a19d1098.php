<?php $__env->startSection('content'); ?>
    <h1> Create Category</h1>
    <hr>
    <button class="btn btn-default"><a href="category/show">View all Categories</a></button>
    <button class="btn btn-default"><a href="category/create">Create new Categories</a></button>
    <hr>
    <?php if( Session::has('coc') ): ?>
    <div class="alert alert-success">
    <button class="close" data-dismiss="alert"></button>
    <strong><?php echo e(session('cc')); ?></strong>
    </div>
    <?php endif; ?>
    <hr>
    <?php if( Session::has('coc')): ?>
    <div class="alert alert-danger">
    <button class="close" data-dismiss="alert"></button>
    <strong><?php echo e(session('coc')); ?></strong>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <?php echo e($error); ?>

            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    </div>
    <hr>
    <?php endif; ?>
    <form method="post" action="<?php echo e(route('category.update',
     $category->id )); ?>">
     <?php echo method_field('patch'); ?>

    <?php echo e(csrf_field()); ?>

        <label>Enter new Category</label>
        <input type="text" name="name" value="<?php echo e($category->name); ?>">
        <input type="submit" name="" value="Update">
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>