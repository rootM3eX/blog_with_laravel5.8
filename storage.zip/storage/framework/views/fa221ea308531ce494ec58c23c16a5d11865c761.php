<?php $__env->startSection('content'); ?>
    <h1>Posts</h1>
    <hr>
    <button class="btn btn-default"><a href="post/show">View all Post</a></button>
    <button class="btn btn-default"><a href="post/create">Create new Post</a></button>
    <hr>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>