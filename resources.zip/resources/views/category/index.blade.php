@extends('home')
@section('content')
    <h1>Category</h1>
    <hr>
    <button class="btn btn-default"><a href="category/show">View all Categories</a></button>
    <button class="btn btn-default"><a href="category/create">Create new Categories</a></button>
    <hr>
@endsection