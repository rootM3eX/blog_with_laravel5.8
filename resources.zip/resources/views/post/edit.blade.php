@extends('home')
@section('content')
    <h1> Edit post</h1>
    <hr>
    <button class="btn btn-default"><a href="post/show">View all Posts</a></button>
    <button class="btn btn-default"><a href="post/create">Create new Posts</a></button>
    <hr>
    @if( Session::has('coc') )
    <div class="alert alert-success">
    <button class="close" data-dismiss="alert"></button>
    <strong>{{ session('cc') }}</strong>
    </div>
    @endif
    <hr>
    @if( Session::has('coc'))
    <div class="alert alert-danger">
    <button class="close" data-dismiss="alert"></button>
    <strong>{{ session('coc')}}</strong>
    <ul>
        @foreach ($errors->all() as $error)
            <li>
                {{$error}}
            </li>
            @endforeach
    </ul>
    </div>
    <hr>
    @endif
    
    <form method="post" action="{{ route('post.update',
     $post->id ) }}">
     {!! method_field('patch') !!}
    {{ csrf_field() }}
    <fieldset>
    <legend>Create Post</legend>
    <div class="form-group">
      <label for="exampleInputEmail1">Enter Title</label>
      <input type="text" class="form-control" name="title" placeholder="Enter Title" value="{{ $post->title }}">
      </div>
    <div class="form-group">
      <label for="exampleInputPassword1">Author</label>
      <input type="text" class="form-control" name="author" placeholder="Author" value="{{ $post->author }}">
    </div>
    <div class="form-group">
      <label for="exampleSelect1">select</label>
      <select class="form-control" id="exampleSelect1" name="category_id">
      @foreach($categories as $category)
        <option value="{{ $post->category_id }}">{{ $category->name }}</option>
        @endforeach
      </select>
    </div>
    <div class="form-group">
      <label for="exampleTextarea">Enter Description</label>
      <textarea class="form-control" name="description" rows="3" placeholder="{{ $post->description }}"></textarea>
    </div>
    <div class="form-group">
      <label for="exampleInputFile">File input</label>
      <input type="file" name="image" class="form-control-file" aria-describedby="fileHelp">
      <small id="fileHelp" class="form-text text-muted">Enter image</small>
    </div>
    <button type="submit" class="btn btn-primary"> Update</button>
  </fieldset>
</form>
@endsection